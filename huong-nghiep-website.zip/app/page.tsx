import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, Users, TrendingUp, Award, ArrowRight, Star } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <BookOpen className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Hướng Nghiệp</h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link href="#services" className="text-gray-600 hover:text-blue-600 transition-colors">
                Dịch vụ
              </Link>
              <Link href="#about" className="text-gray-600 hover:text-blue-600 transition-colors">
                Về chúng tôi
              </Link>
              <Link href="#contact" className="text-gray-600 hover:text-blue-600 transition-colors">
                Liên hệ
              </Link>
            </nav>
            <Button>Đăng ký tư vấn</Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Định hướng tương lai
              <span className="text-blue-600 block">nghề nghiệp của bạn</span>
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Khám phá tiềm năng, tìm kiếm đam mê và xây dựng con đường sự nghiệp phù hợp với bản thân bạn
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-lg px-8 py-3">
                Bắt đầu ngay
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-3">
                Tìm hiểu thêm
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Dịch vụ của chúng tôi</h3>
            <p className="text-lg text-gray-600">Hỗ trợ toàn diện cho hành trình phát triển nghề nghiệp</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Tư vấn cá nhân</CardTitle>
                <CardDescription>Phân tích tính cách, năng lực và định hướng nghề nghiệp phù hợp</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Đánh giá tính cách MBTI</li>
                  <li>• Phân tích năng lực cốt lõi</li>
                  <li>• Lập kế hoạch phát triển</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle>Khóa học kỹ năng</CardTitle>
                <CardDescription>Phát triển kỹ năng mềm và kỹ năng chuyên môn cần thiết</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Kỹ năng giao tiếp</li>
                  <li>• Kỹ năng lãnh đạo</li>
                  <li>• Kỹ năng chuyên môn</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <Award className="h-6 w-6 text-purple-600" />
                </div>
                <CardTitle>Hỗ trợ việc làm</CardTitle>
                <CardDescription>Kết nối với nhà tuyển dụng và cơ hội nghề nghiệp</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Viết CV chuyên nghiệp</li>
                  <li>• Luyện phỏng vấn</li>
                  <li>• Kết nối nhà tuyển dụng</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-white mb-2">5000+</div>
              <div className="text-blue-100">Học viên đã tư vấn</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">95%</div>
              <div className="text-blue-100">Tỷ lệ hài lòng</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">200+</div>
              <div className="text-blue-100">Đối tác tuyển dụng</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">10+</div>
              <div className="text-blue-100">Năm kinh nghiệm</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Phản hồi từ học viên</h3>
            <p className="text-lg text-gray-600">Những câu chuyện thành công của các học viên</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Nguyễn Văn A",
                role: "Kỹ sư phần mềm",
                content:
                  "Nhờ có sự tư vấn của Hướng Nghiệp, tôi đã tìm được công việc phù hợp với đam mê và năng lực của mình.",
              },
              {
                name: "Trần Thị B",
                role: "Marketing Manager",
                content: "Khóa học kỹ năng mềm đã giúp tôi tự tin hơn trong công việc và có được vị trí quản lý.",
              },
              {
                name: "Lê Văn C",
                role: "Doanh nhân",
                content: "Từ một sinh viên mới ra trường, tôi đã có thể khởi nghiệp thành công nhờ lộ trình rõ ràng.",
              },
            ].map((testimonial, index) => (
              <Card key={index} className="bg-white">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4">"{testimonial.content}"</p>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">{testimonial.role}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Sẵn sàng bắt đầu hành trình của bạn?</h3>
          <p className="text-lg text-gray-600 mb-8">
            Đăng ký tư vấn miễn phí ngay hôm nay để khám phá tiềm năng của bản thân
          </p>
          <Button size="lg" className="text-lg px-8 py-3">
            Đăng ký tư vấn miễn phí
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <BookOpen className="h-6 w-6 text-blue-400 mr-2" />
                <span className="text-xl font-bold">Hướng Nghiệp</span>
              </div>
              <p className="text-gray-400">Đồng hành cùng bạn trên con đường phát triển sự nghiệp</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Dịch vụ</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Tư vấn cá nhân</li>
                <li>Khóa học kỹ năng</li>
                <li>Hỗ trợ việc làm</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Về chúng tôi</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Câu chuyện</li>
                <li>Đội ngũ</li>
                <li>Tuyển dụng</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Liên hệ</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@huongnghiep.vn</li>
                <li>Điện thoại: 0123 456 789</li>
                <li>Địa chỉ: Hà Nội, Việt Nam</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Hướng Nghiệp. Tất cả quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
